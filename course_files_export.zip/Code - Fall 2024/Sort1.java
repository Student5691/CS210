public class Sort1 {
    public static void main(String[] args) {
        int a[] = {15, 4, 18, 8, 19, 22, 24, 59, 59, 20, 18, 12, 36, 42, 9};
        int b[] = {4, 8, 9, 12, 15, 18, 18, 19, 20, 22, 24, 36, 42, 59, 59};

        Sort1.iterate(a);
        Sort1.iterate(b);
        
        System.out.println(Sort1.isSorted(a));
        System.out.println(Sort1.isSorted(b));
    }

    public static boolean isSorted(int[] arr){
        for (int i = 0; i < arr.length-1; i++){
            int elem1 = arr[i];
            int elem2 = arr[i+1];

            if (elem1 > elem2){
                return false;
            }
        }
        return true;
    }

    public static void iterate(int[] arr){
        for (int i = 0; i < arr.length; i++){
            System.out.println(arr[i]);
        }
    }
}
