x = [15, 4, 18, 8, 19, 22, 24, 59, 59, 20, 18, 12, 36, 42, 9]

target = 24

# below here, program a linear search

# Problem 1.
# Linear search is a search algorithm that starts from the beginning of an array,
# and checks each element until the search key is found or the end of the array is reached.

for i in range(len(x)):
    val = x[i]

    if val == target:
        print(i)
        break

# Problem 2.
# Given an array of integers "nums" and an integer "target",
# return idicies of the two numbers such that they add up to target

