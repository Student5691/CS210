print("test")

arr1 = [7, 3, 2, 8, 9]

# option 1:
arr1 = arr1 + [10]

# option 2
arr1.append(10)

print(arr1)