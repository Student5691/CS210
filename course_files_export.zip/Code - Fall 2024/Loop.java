public class Loop {
    public static void main(String[] args) {
        int count = 0;

        int a[] = {3, 2, 1, 6};
        int b[] = {7, 2, 3};

        int n = a.length;
        int m = b.length;

        for (int i = 0; i < n; i++){
            for (int j = 0; j < n; j++){
                for (int k = 0; k < n; k++){
                    for (int l = 0; l < n; l++){
                        for (int q = 0; q < m; q++){
                            count++;
                            System.out.println(count);
                        }
                    }
                }
            }
        }
    }
}
