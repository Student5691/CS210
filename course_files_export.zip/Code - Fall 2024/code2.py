queue = []

queue.append("a")
queue.append("b")
queue.append("c")

print(queue)

print(queue.pop(0))
print(queue)

print(queue.pop(0))
print(queue)

print(queue.pop(0))
print(queue)

