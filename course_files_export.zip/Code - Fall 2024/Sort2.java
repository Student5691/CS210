import java.util.Arrays;

public class Sort2 {
    public static void main(String[] args) {
        int a[] = {15, 4, 18, 8, 19, 22, 24, 59, 59, 20, 18, 12, 36, 42, 9};
        int b[] = {4, 8, 9, 12, 15, 18, 18, 19, 20, 22, 24, 36, 42, 59, 59};


        System.out.println(Arrays.toString(a));

        Arrays.sort(a);

        System.out.println(Arrays.toString(a));

    }
}
