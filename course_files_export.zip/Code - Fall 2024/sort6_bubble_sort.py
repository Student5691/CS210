x = [15, 4, 18, 8, 19, 22, 24, 59, 59, 20, 18, 12, 36, 42, 9]

def bubble_sort(arr):
    n = len(arr)

    for i in range(n):
        for j in(range(n-1-i)):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
                # temp = arr[j]
                # arr[j] = arr[j+1]
                # arr[j+1] = temp
    
    return arr

print(x)
print(bubble_sort(x))