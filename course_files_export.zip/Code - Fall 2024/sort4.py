a = [15, 4, 18, 8, 19, 22, 24, 59, 59, 20, 18, 12, 36, 42, 9]
b = [4, 8, 9, 12, 15, 18, 18, 19, 20, 22, 24, 36, 42, 59, 59]

def isSorted(arr):
    n = len(arr)
    
    for i in range(0, n-1, 1):
        elem1 = arr[i]
        elem2 = arr[i+1]
        
        if elem1 > elem2:
            return False

    return True

print(isSorted(a))
print(isSorted(b))