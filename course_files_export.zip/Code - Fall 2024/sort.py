x = [15, 4, 18, 8, 19, 22, 24, 59, 59, 20, 18, 12, 36, 42, 9]
y = [4, 8, 9, 12, 15, 18, 18, 19, 20, 22, 24, 36, 42, 59, 59]

# .sort()
# sorted()

print("x: " + str(x))
print("y: " + str(y))

# print("sorted(x): " + str(sorted(x)))
# x.sort()
# print("x2: " + str(x))

def isSorted(arr):
    return arr == sorted(arr)

# Assignment: Check if x is sorted. Check if y is sorted. Use as much memory / time as you want.

print("x is Sorted? " + str(isSorted(x)))
print("y is Sorted? " + str(isSorted(y)))