x = [15, 4, 18, 8, 19, 22, 24, 59, 59, 20, 18, 12, 36, 42, 9]
y = [4, 8, 9, 12, 15, 18, 18, 19, 20, 22, 24, 36, 42, 59, 59]

print(x)
print(x[1:])

def isSorted(arr):
    zipped = list(zip(arr,arr[1:]))
    for elem in zipped:
        left = elem[0]
        right = elem[1]

        if left > right:
            return False
    
    return True
        # print(str(left) + "," + str(right))

print(isSorted(x))
print(isSorted(y))

def isSorted2(l):
    return all(a <= b for a, b in zip(l, l[1:]))


print(isSorted2(x))
print(isSorted2(y))