#include <iostream>
using namespace std;

int main() {
    // Sorted array
    int x[] = {4, 8, 9, 12, 15, 18, 18, 19, 20, 22, 24, 36, 42, 59, 59};
    int n = sizeof(x) / sizeof(x[0]);

    // Target to search
    int target = 24;

    // Binary Search implementation
    int low = 0;
    int high = n - 1;

    while (low <= high) {
        int mid = low + (high - low) / 2; 

        if (x[mid] == target) {
            cout << "Element found at index: " << mid << endl;
            break;
        }
        else if (x[mid] < target) {
            low = mid + 1;
        }
        else {
            high = mid - 1;
        }
    }

    return 0;
}