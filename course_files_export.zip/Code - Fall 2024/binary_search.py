# Given array
x = [4, 8, 9, 12, 15, 18, 18, 19, 20, 22, 24, 36, 42, 59, 59]

# Define the target
target = 24

# Binary Search implementation
low = 0
high = len(x) - 1

while low <= high:
    mid = (low + high) // 2
    val = x[mid]
    
    if val == target:
        print(mid)
        break
    elif val < target:
        low = mid + 1
    else:
        high = mid - 1