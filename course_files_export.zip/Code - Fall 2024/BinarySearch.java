public class BinarySearch {
    public static void main(String[] args) {
        // Sorted array
        int[] x = {4, 8, 9, 12, 15, 18, 18, 19, 20, 22, 24, 36, 42, 59, 59};

        // Target to search
        int target = 24;

        // Binary Search implementation
        int low = 0;
        int high = x.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;

            if (x[mid] == target) {
                System.out.println("Element found at index: " + mid);
                break;
            } else if (x[mid] < target) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
    }
}
